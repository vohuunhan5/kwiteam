
<html lang="en">
<head>
<meta charset="UTF-8">
<title>404 Page</title>
<script type="text/javascript" src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
<meta name='description' content='Về Nhà Ngủ Đi | LoLi Team'>
<meta property="og:image" content="https://upload.wikimedia.org/wikipedia/commons/5/5b/LoLi_Team_Logo_2.png">
<meta name='Về Nhà Ngủ Đi | LoLi Team'>
<link rel='icon' href='http://www.minjung20.org/Static/close_button.png' sizes='17x17'>
<meta name="keywords" content="LoLi Team EoPi" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/style.css">
<script language=javascript>
            title_tmp1 = document.title
            if (title_tmp1.indexOf(">>") != -1) {
                title_tmp2 = title_tmp1.split(">>");
                title_last = "*~*" + title_tmp2[1];
                title_last = title_last + "*~*" + title_tmp2[2];
            } else {

                if (title_tmp1.indexOf("*~*") != -1) {
                    title_tmp2 = title_tmp1.split("*~*");
                    title_last = "*~*" + title_tmp2[1];
                    if (title_last == "*~*") {
                        title_last = "*~*"
                    };
                    if (title_last == "*~*") {
                        title_last = "*~*"
                    };
                } else {
                    title_last = "404 Page"
                }
            }


            title_new = "" + title_last + ""
            step = 0

            function flash_title() {
                step++
                if (step == 8) {
                    step = 1
                }
                if (step == 1) {
                    document.title = '|----♥' + title_new + '♥----|'
                }
                if (step == 2) {
                    document.title = '|---♥-' + title_new + '-♥---|'
                }
                if (step == 3) {
                    document.title = '|--♥--' + title_new + '--♥--|'
                }
                if (step == 4) {
                    document.title = '|-♥---' + title_new + '---♥-|'
                }
                if (step == 5) {
                    document.title = '|♥----' + title_new + '----♥|'
                }
                if (step == 6) {
                    document.title = '|-♥---' + title_new + '---♥-|'
                }
                if (step == 7) {
                    document.title = '|--♥--' + title_new + '--♥--|'
                }
                if (step == 8) {
                    document.title = '|---♥-' + title_new + '-♥---|'
                }
                if (step == 9) {
                    document.title = '|----♥' + title_new + '♥----|'
                }
                setTimeout("flash_title()", 180);
            }
            flash_title()
        </script>
</head>
<body>
<div id="particles-js">
<canvas class="particles-js-canvas-el" style="width: 100%; height: 100%;">
</canvas>
</div>
<div class="container">
<div class="text">
<h1 style="text-shadow: -3px 0 0 rgba(255,0,0,.7),
		3px 0 0 rgba(0,255,255,.7);">
<font style="background: url('https://loliteam.net/src/chopnhay.gif') 
repeat scroll 0% 2% transparent; color:#F8E8E8;text-shadow: 0 0 0.7em #DB1230,0 0 0.5em #DB1230">
LOLI SEC TEAM</font>
</h1>
<h2 style="text-shadow: -3px 0 0 rgba(255,0,0,.7),
		3px 0 0 rgba(0,255,255,.7);">Go <a href="https://loliteam.net">hom<span>e</span></a>&nbsp; You're Drunk </h2>
</div>
</div>
<script src="js/index.js"></script>
<iframe src="https://www.nhaccuatui.com/mh/background/X3asFdF2ZobI" width="0" height="0" frameborder="0" allowfullscreen></iframe>
</body>
</html>