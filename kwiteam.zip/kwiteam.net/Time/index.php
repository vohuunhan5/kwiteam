
<html lang="en" class="no-js">
<head>
<meta charset="UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name='description' content='Time Kawaii Team | LoLi Team'>
<meta property="og:image" content="https://yt3.ggpht.com/-AqgJa6sbRoo/AAAAAAAAAAI/AAAAAAAAAAA/ubDx4SsbXuo/s900-c-k-no-mo-rj-c0xffffff/photo.jpg">
<meta name='Security Update | LoLi Team'>
<link rel='icon' href='https://marketplace.canva.com/MAB48Xu3f-I/1/thumbnail/canva-heart-icon-MAB48Xu3f-I.png' sizes='17x17'>
<meta name="keywords" content="LoLI Team Kawaii Team" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Time Kawaii Team</title>
<link rel="stylesheet" type="text/css" href="css/normalize.css" />
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/demo.css" />
<link rel="stylesheet" type="text/css" href="css/component.css" />
<script language=javascript>
        title_tmp1 = document.title
        if (title_tmp1.indexOf(">>") != -1) {
            title_tmp2 = title_tmp1.split(">>");
            title_last = "*~*" + title_tmp2[1];
            title_last = title_last + "*~*" + title_tmp2[2];
        } else {

            if (title_tmp1.indexOf("*~*") != -1) {
                title_tmp2 = title_tmp1.split("*~*");
                title_last = "*~*" + title_tmp2[1];
                if (title_last == "*~*") {
                    title_last = "*~*"
                };
                if (title_last == "*~*") {
                    title_last = "*~*"
                };
            } else {
                title_last = "Time Kawaii Team"
            }
        }


        title_new = "" + title_last + ""
        step = 0

        function flash_title() {
            step++
            if (step == 8) {
                step = 1
            }
            if (step == 1) {
                document.title = '|----♥' + title_new + '♥----|'
            }
            if (step == 2) {
                document.title = '|---♥-' + title_new + '-♥---|'
            }
            if (step == 3) {
                document.title = '|--♥--' + title_new + '--♥--|'
            }
            if (step == 4) {
                document.title = '|-♥---' + title_new + '---♥-|'
            }
            if (step == 5) {
                document.title = '|♥----' + title_new + '----♥|'
            }
            if (step == 6) {
                document.title = '|-♥---' + title_new + '---♥-|'
            }
            if (step == 7) {
                document.title = '|--♥--' + title_new + '--♥--|'
            }
            if (step == 8) {
                document.title = '|---♥-' + title_new + '-♥---|'
            }
            if (step == 9) {
                document.title = '|----♥' + title_new + '♥----|'
            }
            setTimeout("flash_title()", 180);
        }
        flash_title()
    </script>
</head>
<body>
<div class="container demo-1">
<div class="content">
<div id="large-header" class="large-header">
<div style="position:absolute;left: 520px; top:505px;" class="time" id="time" data-hours="" data-minutes="">
<div class="digit">
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
</div>
<div class="digit">
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
</div>
<div class="digit">
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
</div>
<div class="digit">
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
</div>
<div class="digit">
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
</div>
<div class="digit">
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
</div>
<center>
<font size="7" face="Tahoma" style="background: url('./src/chopnhay.gif') 
repeat scroll 0% 2% transparent; color:#ffffff;text-shadow: 0 0 0.7em #FA3939,0 0 0.5em #FA3939">Võ<br> Hữu Nhân</font></center>
</div>
<canvas id="demo-canvas"></canvas>
</div>
</div>
</div>
<script src="js/TweenLite.min.js"></script>
<script src="js/EasePack.min.js"></script>
<script src="js/rAF.js"></script>
<script src="js/demo-1.js"></script>
<script src='js/Rx.min.js'></script>
<script src='js/rxcss.min.js'></script>
<script src="js/index.js"></script>
<iframe src="https://www.nhaccuatui.com/mh/background/HIWX4ZCwxIbM" width="1" height="1" frameborder="0" allowfullscreen allow="autoplay"></iframe>
</body>
</html>
