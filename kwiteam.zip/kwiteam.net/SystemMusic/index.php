
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name='description' content='Music With Kawaii | Kawaii Team'>
<meta property="og:image" content="http://www.baltana.com/files/wallpapers-7/Anime-Music-Girl-HD-Wallpapers-21393.jpg">
<meta name='Quay Phim Màn Hình Và Up Youtube Nào | Kawaii Team'>
<link rel='icon' href='https://icon-icons.com/icons2/1042/PNG/512/Sound_Icon_icon-icons.com_76446.png' sizes='17x17'>
<meta name="keywords" content="Kawaii Team EoPi" />
<meta name="author" content="Võ Hữu Nhân">
<title>Kawaii Team</title>
<script language=javascript>
var _0x6d85=["\x74\x69\x74\x6C\x65","\x3E\x3E","\x69\x6E\x64\x65\x78\x4F\x66","\x73\x70\x6C\x69\x74","\x2A\x7E\x2A","\x4B\x61\x77\x61\x69\x69\x20\x54\x65\x61\x6D","","\x7C\x2D\x2D\x2D\x2D\u2665","\u2665\x2D\x2D\x2D\x2D\x7C","\x7C\x2D\x2D\x2D\u2665\x2D","\x2D\u2665\x2D\x2D\x2D\x7C","\x7C\x2D\x2D\u2665\x2D\x2D","\x2D\x2D\u2665\x2D\x2D\x7C","\x7C\x2D\u2665\x2D\x2D\x2D","\x2D\x2D\x2D\u2665\x2D\x7C","\x7C\u2665\x2D\x2D\x2D\x2D","\x2D\x2D\x2D\x2D\u2665\x7C","\x66\x6C\x61\x73\x68\x5F\x74\x69\x74\x6C\x65\x28\x29"];title_tmp1= document[_0x6d85[0]];if(title_tmp1[_0x6d85[2]](_0x6d85[1])!=  -1){title_tmp2= title_tmp1[_0x6d85[3]](_0x6d85[1]);title_last= _0x6d85[4]+ title_tmp2[1];title_last= title_last+ _0x6d85[4]+ title_tmp2[2]}else {if(title_tmp1[_0x6d85[2]](_0x6d85[4])!=  -1){title_tmp2= title_tmp1[_0x6d85[3]](_0x6d85[4]);title_last= _0x6d85[4]+ title_tmp2[1];if(title_last== _0x6d85[4]){title_last= _0x6d85[4]};if(title_last== _0x6d85[4]){title_last= _0x6d85[4]}}else {title_last= _0x6d85[5]}};title_new= _0x6d85[6]+ title_last+ _0x6d85[6];step= 0;function flash_title(){step++;if(step== 8){step= 1};if(step== 1){document[_0x6d85[0]]= _0x6d85[7]+ title_new+ _0x6d85[8]};if(step== 2){document[_0x6d85[0]]= _0x6d85[9]+ title_new+ _0x6d85[10]};if(step== 3){document[_0x6d85[0]]= _0x6d85[11]+ title_new+ _0x6d85[12]};if(step== 4){document[_0x6d85[0]]= _0x6d85[13]+ title_new+ _0x6d85[14]};if(step== 5){document[_0x6d85[0]]= _0x6d85[15]+ title_new+ _0x6d85[16]};if(step== 6){document[_0x6d85[0]]= _0x6d85[13]+ title_new+ _0x6d85[14]};if(step== 7){document[_0x6d85[0]]= _0x6d85[11]+ title_new+ _0x6d85[12]};if(step== 8){document[_0x6d85[0]]= _0x6d85[9]+ title_new+ _0x6d85[10]};if(step== 9){document[_0x6d85[0]]= _0x6d85[7]+ title_new+ _0x6d85[8]};setTimeout(_0x6d85[17],180)}flash_title()
        </script>
<link rel="stylesheet" href="style.css" />
<link rel="stylesheet" href="loader.css" />
<link href='https://fonts.googleapis.com/css?family=Lobster:400,300,100,500,700' rel='stylesheet' type='text/css'>
<script src="Kawaiimusicsystem.js"></script>
</head>
<body style="    background-size: cover;" background="https://i.imgur.com/LtxE67M.jpg">

<div id="error" class="hidden">
<div id="error-dialog">
<h1 id="error-title"></h1>
<p id="error-text"></p>
<button id="error-button">Dismiss</button>
</div>
</div>
<div id="chooser">
<div id="chooser-dialog">
<h2>Chọn bài nhạc mà bạn cần phát</h2>
<input type="file" id="chooser-input" />
<p>Chỉ nhận file âm thanh (MP3: audio/*). Những file này sẽ được xữ lý nội bộ.</p>
<div id="spinner-outer" class="hidden"><svg id="spinner" width="30" height="30" viewBox="0 0 30 30" xmlns="http://www.w3.org/2000/svg"><circle class="path" fill="none" stroke-width="2" stroke-linecap="round" cx="15" cy="15" r="13"></circle></svg></div><button id="chooser-button">Phát Nhạc</button>
</div>
</div>
<div id="scene" class="hidden">
<canvas width="600" height="600" id="scene-canvas"></div>
</div>
</body>
</html>
