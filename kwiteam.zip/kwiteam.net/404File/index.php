
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name='description' content='Đéo Có File Đâu| LoLi Team'>
<meta property="og:image" content="https://upload.wikimedia.org/wikipedia/commons/5/5b/LoLi_Team_Logo_2.png">
<meta name='Đéo Có File Đâu | LoLi Team'>
<link rel='icon' href='https://cdn0.iconfinder.com/data/icons/thin-files-documents/57/thin-065_paper_document_file_error_unavailable_delete-512.png' sizes='17x17'>
<meta name="keywords" content="LoLi Team EoPi" />
<title>404 - Not File</title>
<link rel="stylesheet" href="css/style.css">
<script language=javascript>
            title_tmp1 = document.title
            if (title_tmp1.indexOf(">>") != -1) {
                title_tmp2 = title_tmp1.split(">>");
                title_last = "*~*" + title_tmp2[1];
                title_last = title_last + "*~*" + title_tmp2[2];
            } else {

                if (title_tmp1.indexOf("*~*") != -1) {
                    title_tmp2 = title_tmp1.split("*~*");
                    title_last = "*~*" + title_tmp2[1];
                    if (title_last == "*~*") {
                        title_last = "*~*"
                    };
                    if (title_last == "*~*") {
                        title_last = "*~*"
                    };
                } else {
                    title_last = "404 - Not File"
                }
            }


            title_new = "" + title_last + ""
            step = 0

            function flash_title() {
                step++
                if (step == 8) {
                    step = 1
                }
                if (step == 1) {
                    document.title = '|----♥' + title_new + '♥----|'
                }
                if (step == 2) {
                    document.title = '|---♥-' + title_new + '-♥---|'
                }
                if (step == 3) {
                    document.title = '|--♥--' + title_new + '--♥--|'
                }
                if (step == 4) {
                    document.title = '|-♥---' + title_new + '---♥-|'
                }
                if (step == 5) {
                    document.title = '|♥----' + title_new + '----♥|'
                }
                if (step == 6) {
                    document.title = '|-♥---' + title_new + '---♥-|'
                }
                if (step == 7) {
                    document.title = '|--♥--' + title_new + '--♥--|'
                }
                if (step == 8) {
                    document.title = '|---♥-' + title_new + '-♥---|'
                }
                if (step == 9) {
                    document.title = '|----♥' + title_new + '♥----|'
                }
                setTimeout("flash_title()", 180);
            }
            flash_title()
        </script>
</head>
<body>
<div class="error">
<div class="wrap">
<div class="404">
<pre><code>
	 <span class="green">&lt;!</span><span>DOCTYPE html</span><span class="green">&gt;</span>
<span class="orange">&lt;html&gt;</span>
	<span class="blue">&lt;title&gt;</span>
		<span class="green">LoLi Sec Team</span>
	<span class="blue">&lt;/title&gt;</span>
    <span class="orange">&lt;style&gt;</span>
   * {
		        <span class="green">everything</span>:<span class="blue">LoLiTeam</span>;
}
     <span class="orange">&lt;/style&gt;</span>
 <span class="orange">&lt;body&gt;</span> 
              ERROR 404!
				FILE NOT FOUND!
				<span class="comment">&lt;!--Tệp tin mà bạn đang cố tải, 
					có thể đéo có ở đây đâu.--&gt;
		</span>
 <span class="orange"></span> 
			  


</div>
<br />
<span class="info">
<br />
</br>
</br>

<span class="orange">&nbsp;&lt;/body&gt;</span>

<br />
      <span class="orange">&lt;/html&gt;</span>
    </code></pre>
</div>
</div>
</span>
<iframe src="https://www.nhaccuatui.com/mh/background/NWoIssjaPw" width="0" height="0" frameborder="0" allowfullscreen></iframe>
</body>
</html>