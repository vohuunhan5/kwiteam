
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name='description' content='Crack Password | LoLi Team'>
<meta property="og:image" content="https://pbs.twimg.com/profile_images/882554149501411329/Paknbh2i_400x400.jpg">
<meta name='Crack Password | LoLi Team'>
<title>Crack Password</title>
<script language=javascript>
        title_tmp1 = document.title
        if (title_tmp1.indexOf(">>") != -1) {
            title_tmp2 = title_tmp1.split(">>");
            title_last = "*~*" + title_tmp2[1];
            title_last = title_last + "*~*" + title_tmp2[2];
        } else {

            if (title_tmp1.indexOf("*~*") != -1) {
                title_tmp2 = title_tmp1.split("*~*");
                title_last = "*~*" + title_tmp2[1];
                if (title_last == "*~*") {
                    title_last = "*~*"
                };
                if (title_last == "*~*") {
                    title_last = "*~*"
                };
            } else {
                title_last = "Crack Password"
            }
        }


        title_new = "" + title_last + ""
        step = 0

        function flash_title() {
            step++
            if (step == 8) {
                step = 1
            }
            if (step == 1) {
                document.title = '|----♥' + title_new + '♥----|'
            }
            if (step == 2) {
                document.title = '|---♥-' + title_new + '-♥---|'
            }
            if (step == 3) {
                document.title = '|--♥--' + title_new + '--♥--|'
            }
            if (step == 4) {
                document.title = '|-♥---' + title_new + '---♥-|'
            }
            if (step == 5) {
                document.title = '|♥----' + title_new + '----♥|'
            }
            if (step == 6) {
                document.title = '|-♥---' + title_new + '---♥-|'
            }
            if (step == 7) {
                document.title = '|--♥--' + title_new + '--♥--|'
            }
            if (step == 8) {
                document.title = '|---♥-' + title_new + '-♥---|'
            }
            if (step == 9) {
                document.title = '|----♥' + title_new + '♥----|'
            }
            setTimeout("flash_title()", 180);
        }
        flash_title()
    </script>
<link href='https://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="info">
<p>Chào bạn nếu bạn đang cố gắn truy cập vào một website hay cái đéo gì đó và bạn đéo biết mật khẩu hay bị Firewall nó chặn lại,
<br>bạn sẽ phải cần đến phương pháp brute-force này,...</p>
<br>-->Đừng quên theo dõi Oppa Eopi đáng yêu của chúng ta tại
<a href="https://www.facebook.com/Thuong.EoPi" target="_blank" title="Click để vào trang cá nhân của EoPi">Facebook</a>
nhé</p>
<p class="hidden">Nhấn đại một cái nút nào đó (nhấn liên tục nút space luôn đi) để nó ra mật khẩu từ từ nhé thằng bệnh<span class="blink">_</span></p>
</div>
<div class="password hidden"></div>
<div class="button start">BẮT ĐẦU HACK!</div>
<div class="blink granted hidden">HACK XONG RỒI ĐÓ TML!</div>
<div class=" button rerun hidden">HACK LẠI PHÁT NỮA!</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
<iframe src="https://www.nhaccuatui.com/mh/background/v4jPDkaO3SSu" width="1" height="1" frameborder="0" allowfullscreen></iframe>
</body>
</html>
