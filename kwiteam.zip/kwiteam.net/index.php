
<html>
<head>
<title>Kawaii Team</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta charset="utf-8" />
<meta name="Author" content="Võ Hữu Nhân">
<meta name="copyright" content="Kawaii Sec Team">
<meta name="description" content="Welcome to website of Kawaii Sec Team">
<meta property="og:image" content="http://kwiteam.net/images/avatar.jpg">
<meta property="og:title" content="Kawaii Sec Team">
<link rel="shortcut icon" href="favicon.ico">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
<link rel="stylesheet" href="/css/main.css" />
<noscript>
        <link rel="stylesheet" href="/css/noscript.css" /></noscript>
<script language=javascript>
     var _0xa822=["\x74\x69\x74\x6C\x65","\x3E\x3E","\x69\x6E\x64\x65\x78\x4F\x66","\x73\x70\x6C\x69\x74","\x2A\x7E\x2A","\x4B\x61\x77\x61\x69\x69\x20\x54\x65\x61\x6D","","\x7C\x2D\x2D\x2D\x2D\u2665","\u2665\x2D\x2D\x2D\x2D\x7C","\x7C\x2D\x2D\x2D\u2665\x2D","\x2D\u2665\x2D\x2D\x2D\x7C","\x7C\x2D\x2D\u2665\x2D\x2D","\x2D\x2D\u2665\x2D\x2D\x7C","\x7C\x2D\u2665\x2D\x2D\x2D","\x2D\x2D\x2D\u2665\x2D\x7C","\x7C\u2665\x2D\x2D\x2D\x2D","\x2D\x2D\x2D\x2D\u2665\x7C","\x66\x6C\x61\x73\x68\x5F\x74\x69\x74\x6C\x65\x28\x29"];title_tmp1= document[_0xa822[0]];if(title_tmp1[_0xa822[2]](_0xa822[1])!=  -1){title_tmp2= title_tmp1[_0xa822[3]](_0xa822[1]);title_last= _0xa822[4]+ title_tmp2[1];title_last= title_last+ _0xa822[4]+ title_tmp2[2]}else {if(title_tmp1[_0xa822[2]](_0xa822[4])!=  -1){title_tmp2= title_tmp1[_0xa822[3]](_0xa822[4]);title_last= _0xa822[4]+ title_tmp2[1];if(title_last== _0xa822[4]){title_last= _0xa822[4]};if(title_last== _0xa822[4]){title_last= _0xa822[4]}}else {title_last= _0xa822[5]}};title_new= _0xa822[6]+ title_last+ _0xa822[6];step= 0;function flash_title(){step++;if(step== 8){step= 1};if(step== 1){document[_0xa822[0]]= _0xa822[7]+ title_new+ _0xa822[8]};if(step== 2){document[_0xa822[0]]= _0xa822[9]+ title_new+ _0xa822[10]};if(step== 3){document[_0xa822[0]]= _0xa822[11]+ title_new+ _0xa822[12]};if(step== 4){document[_0xa822[0]]= _0xa822[13]+ title_new+ _0xa822[14]};if(step== 5){document[_0xa822[0]]= _0xa822[15]+ title_new+ _0xa822[16]};if(step== 6){document[_0xa822[0]]= _0xa822[13]+ title_new+ _0xa822[14]};if(step== 7){document[_0xa822[0]]= _0xa822[11]+ title_new+ _0xa822[12]};if(step== 8){document[_0xa822[0]]= _0xa822[9]+ title_new+ _0xa822[10]};if(step== 9){document[_0xa822[0]]= _0xa822[7]+ title_new+ _0xa822[8]};setTimeout(_0xa822[17],180)}flash_title()
    </script>
</head>
<body background="https://i.imgur.com/LtxE67M.jpg" style="    background-size: cover;">
<div id="wrapper">
<section id="main">
<header>
<span class="avatar"><img src="images/avatar.jpg" alt="" /></span>
<h1>
<font size="9" style="background: url(&quot;src/chopnhay.gif&quot;) 
						repeat scroll 0% 0% transparent; color:white;text-shadow: 0 0 0.2em #241D1B,0 0 0.2em #241D1B">Kawaii Team</font>
</h1>
<p>No Definition Of</br> | " Can Not " |</br>| " Safety System " |</br>| " Key And CopyRight " |</p>
</header>
<footer>
<ul class="icons">
<li><a href="https://www.ketnoi369.com/" target="_blank" class="fa-rss">Blog</a></li>
<li><a href="https://198.13.43.237:4444/" target="_blank" class="fa-shield">Firewall</a></li>
<li><a href="https://loli-s.info/" target="_blank" class="fa-heartbeat">KWIT S</a></li>
<li><a href="https://www.youtube.com/channel/UC0HE9IQZ6X85f1dequ07bxA" target="_blank" class="fa-youtube">Youtube</a></li>
<li><a href="/adidaphat/" target="_blank" class="fa-eye">Phat</a></li>
<li><a href="https://ctf.kwiteam.net/" target="_blank" class="fa-fire">CTF</a></li>
<li><a href="https://chat.kwiteam.net/" target="_blank" class="fa-comments">Chat Server</a></li>
 </ul>
</footer>
<ul class="actions special">
<li><a href="Time" class="button" target="_blank">KWIT Time</a></li>
<li><a href="SystemMusic" class="button" target="_blank">SystemMusic</a></li>
</ul>
<ul class="actions special">
<li><a href="404Page" class="button" target="_blank">404Page</a></li>
<li><a href="404File" class="button" target="_blank">404File</a></li>
</ul>
<ul class="actions special">
<li><a href="Info" class="button" target="_blank">News</a></li>
<li><a href="Crack" class="button" target="_blank">Hack</a></li>
</ul>
</section>
<footer id="footer">
<ul class="copyright">
<li>&copy; Kawaii Team</li>
</ul>
</footer>
</div>
<script>
        if ('addEventListener' in window) {
            window.addEventListener('load', function() {
                document.body.className = document.body.className.replace(/\bis-preload\b/, '');
            });
            document.body.className += (navigator.userAgent.match(/(MSIE|rv:11\.0)/) ? ' is-ie' : '');
        }
    </script>
<iframe width="0" height="0" scrolling="no" frameborder="no" allow="autoplay" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/427445127&color=%23ff5500&auto_play=true&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true&visual=true"></iframe>
</body>
</html>
