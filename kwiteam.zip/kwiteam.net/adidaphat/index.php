
<html lang="en">
<head>
<meta charset="UTF-8">
<title>A Di Đà Phật</title>
<meta charset="utf-8" />
<meta name="Author" content="Shiina EoPi">
<meta name="copyright" content="LoLi Sec Team">
<meta name="description" content="Nam Mô A Di Đà Phật">
<meta property="og:image" content="/adidaphat/title.png">
<meta property="og:title" content="Nam Mô A Di Đà Phật">
<link rel="shortcut icon" href="favicon.ico">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link href="https://fonts.googleapis.com/css?family=K2D" rel="stylesheet">
<link rel="stylesheet" href="http://kwiteam.net/adidaphat/style.css">
</head>
<body>
<body>
<header id="mainHeader">
<div class="container clear-fix">
<div class="cloud1"></div>
<div class="cloud2"></div>
<div class="cloud3"></div>
<div class="logo">
<img src="../images/avatar.jpg" style="    border-radius: 100%;width:200px;height:200px">
<h1>
<font style="background: url(../src/chopnhay.gif) 
			repeat scroll 0% 0% transparent; color:white;text-shadow: 0 0 0.2em #241D1B,0 0 0.2em #241D1B">
Nam Mô
</font>
</h1>
<h2>
<font style="background: url(../src/chopnhay.gif) 
			repeat scroll 0% 0% transparent; color:white;text-shadow: 0 0 0.2em #241D1B,0 0 0.2em #241D1B">
Bổn Sư Thích Ca
</font>
</h2>
<h2>
<font style="background: url(../src/chopnhay.gif) 
			repeat scroll 0% 0% transparent; color:white;text-shadow: 0 0 0.2em #241D1B,0 0 0.2em #241D1B">
Mâu Ni Phật
</font>
</h2>
</div>
</div>
</header>
<script type="text/javascript" src="js/lib/jquery-2.2.0.min.js"></script>
<script type="text/javascript" src="js/functions.js"></script>
<iframe src="https://www.nhaccuatui.com/mh/background/cIUzE1R3u9Mr" width="1" height="1" frameborder="0" allowfullscreen allow="autoplay"></iframe>
</body>
</body>
</html>
